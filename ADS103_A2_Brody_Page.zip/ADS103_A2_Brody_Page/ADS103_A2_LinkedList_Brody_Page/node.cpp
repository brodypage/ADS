#include "node.h"

Node::Node()
{
	next = NULL;
}
Node::Node(int element)
{
	next = NULL;

	this->element = element;
}
